	<div class="row w-100 mt-3">
		<div class="col">
			<h1 class="text-center">Đã đặt hàng thành công </h1>		
		</div>
		
		
	</div>
	<div class="row">
		<div class="col">
			<a class="btn btn-primary" href="/Home">Quay lại mua các sản phẩm khác</a>
		</div>
		
	</div>
	<div class="row w-100" style="height:100vh">
		
	</div>
