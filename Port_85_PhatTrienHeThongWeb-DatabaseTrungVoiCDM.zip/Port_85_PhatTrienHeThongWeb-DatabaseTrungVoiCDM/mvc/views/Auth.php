<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../../public/CSS/main.css">
    <link rel="stylesheet" href="../../../public/CSS/w3.css">
    <link rel="stylesheet" href="../../../public/CSS/font-awesome.css">
    <link rel="stylesheet" href="../../../public/CSS/grid-product.css">
    <link rel="stylesheet" href="../../../public/CSS/bootstrap.min.css">
    <link rel="stylesheet" href="../../../public/CSS/TAI.css">

    <script type="text/javascript" src="../../../public/JS/jquery.min.js"></script>
    <script type="text/javascript" src="../../../public/JS/jquery.dataTables.min.js"></script>

    <script type="text/javascript" src="../../../public/JS/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="../../../public/JS/TAI.js"></script>

    <script type="text/javascript" src="../../../public/sweetalert/node_modules/sweetalert2/dist/sweetalert2.js"></script>
    <link rel="stylesheet" href="../../../public/sweetalert/node_modules/sweetalert2/dist/sweetalert2.css">


    
	<title><?=$data['Title']?></title>
</head>
<body>
	<div class="container-fluid p-0">
		<div class="row bg-dark m-0">
			sdlas;dlkasd;kl
		</div>
		<div class="row">
			<?php require_once($_SERVER['DOCUMENT_ROOT'].'/mvc/views/pages/'.$data['Page']). '.php'?>
		</div>
	</div>
</body>
</html>